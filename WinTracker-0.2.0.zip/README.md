# WinTracker

Personal log of wins with value, tags and statistics. Macosh Apps.

- Add, edit and delete wins with validation (title, date `YYYY-MM-DD`, amount).
- Amounts are exact decimals (`BigDecimal`), not floating point.
- Search by title or tag.
- Statistics: totals, average, largest win, per year, per tag, last 12 months.
- Polish, English and Spanish.
- JSON export and import. Import shows a preview and asks before replacing data.
- Reads data saved by v0.1.

Build: GitHub Actions runs unit tests and then the debug APK.
