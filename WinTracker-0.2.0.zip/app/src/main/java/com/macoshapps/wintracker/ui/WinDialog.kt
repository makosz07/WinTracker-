package com.macoshapps.wintracker.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.macoshapps.wintracker.domain.Money
import com.macoshapps.wintracker.domain.Win
import com.macoshapps.wintracker.i18n.L
import java.time.LocalDate
import java.util.UUID

/** Add or edit a win. onSave is called only with valid data; onDelete is called after confirmation. */
@Composable
fun WinDialog(
    lang: String,
    initial: Win?,
    onSave: (Win) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val t = L(lang)
    var titleText by rememberSaveable { mutableStateOf(initial?.title ?: "") }
    var dateText by rememberSaveable { mutableStateOf(initial?.date?.toString() ?: LocalDate.now().toString()) }
    var amountText by rememberSaveable { mutableStateOf(initial?.amount?.toPlainString() ?: "") }
    var tagsText by rememberSaveable { mutableStateOf(initial?.tags?.joinToString(", ") ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    val parsedDate = runCatching { LocalDate.parse(dateText.trim()) }.getOrNull()
    val parsedAmount = Money.parse(amountText)
    val problem: String? = when {
        titleText.isBlank() -> t("Wpisz nazwę wygranej", "Enter a title", "Introduce un nombre")
        parsedDate == null -> t("Data w formacie RRRR-MM-DD", "Date as YYYY-MM-DD", "Fecha como AAAA-MM-DD")
        parsedAmount == null -> t("Nieprawidłowa wartość", "Invalid amount", "Valor no válido")
        else -> null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (initial == null) t("Dodaj wygraną", "Add win", "Añadir premio")
                else t("Edytuj wygraną", "Edit win", "Editar premio")
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it.take(Win.MAX_TITLE) },
                    label = { Text(t("Nazwa", "Title", "Nombre")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text(t("Data (RRRR-MM-DD)", "Date (YYYY-MM-DD)", "Fecha (AAAA-MM-DD)")) },
                    singleLine = true,
                    isError = parsedDate == null,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text(t("Wartość", "Value", "Valor")) },
                    singleLine = true,
                    isError = parsedAmount == null,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = tagsText,
                    onValueChange = { tagsText = it },
                    label = { Text(t("Tagi (po przecinku)", "Tags (comma separated)", "Etiquetas (separadas por comas)")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                problem?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                if (initial != null) {
                    TextButton(onClick = { confirmDelete = true }) {
                        Text(t("Usuń wygraną", "Delete win", "Eliminar premio"), color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = problem == null,
                onClick = {
                    val date = checkNotNull(parsedDate)
                    val amount = checkNotNull(parsedAmount)
                    onSave(
                        Win(
                            id = initial?.id ?: UUID.randomUUID().toString(),
                            title = titleText.trim(),
                            date = date,
                            amount = amount,
                            tags = Win.parseTags(tagsText),
                        )
                    )
                },
            ) { Text(t("Zapisz", "Save", "Guardar")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(t("Anuluj", "Cancel", "Cancelar")) } },
    )

    if (confirmDelete && initial != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(t("Usunąć wygraną?", "Delete this win?", "¿Eliminar este premio?")) },
            text = { Text(initial.title) },
            confirmButton = {
                TextButton(onClick = { onDelete(initial.id) }) {
                    Text(t("Usuń", "Delete", "Eliminar"), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(t("Anuluj", "Cancel", "Cancelar")) } },
        )
    }
}
