package com.macoshapps.wintracker.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.macoshapps.wintracker.data.WinStore
import com.macoshapps.wintracker.domain.Win
import com.macoshapps.wintracker.i18n.L

@Composable
fun WinTrackerApp(store: WinStore) {
    val context = LocalContext.current
    val t = L(store.language)
    var page by rememberSaveable { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Win?>(null) }
    var creating by remember { mutableStateOf(false) }
    var importPreview by remember { mutableStateOf<List<Win>?>(null) }

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(store.exportJson().toByteArray(Charsets.UTF_8))
                } ?: throw IllegalStateException("no output")
            }.onSuccess {
                toast(t("Kopia zapisana", "Backup saved", "Copia guardada"))
            }.onFailure {
                toast(t("Nie udało się zapisać pliku", "Could not write the file", "No se pudo escribir el archivo"))
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val json = context.contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)
                    ?.use { it.readText() }
                    ?: throw IllegalStateException("no input")
                WinStore.decode(json)
            }.onSuccess { list ->
                importPreview = list
            }.onFailure {
                toast(t("To nie jest poprawna kopia WinTrackera", "This is not a valid WinTracker backup", "Esta no es una copia válida de WinTracker"))
            }
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val labels = listOf(
                    t("Wygrane", "Wins", "Premios"),
                    t("Statystyki", "Statistics", "Estadísticas"),
                    t("Ustawienia", "Settings", "Ajustes"),
                )
                val icons = listOf("★", "▥", "⚙")
                labels.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = page == index,
                        onClick = { page = index },
                        icon = { Text(icons[index]) },
                        label = { Text(label) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize().statusBarsPadding()) {
            when (page) {
                0 -> WinsScreen(
                    store = store,
                    onAdd = { creating = true },
                    onEdit = { editing = it },
                )
                1 -> StatsScreen(store)
                else -> SettingsScreen(
                    store = store,
                    onExport = { exportLauncher.launch("wintracker-backup.json") },
                    onImport = { importLauncher.launch(arrayOf("application/json", "text/plain")) },
                )
            }
        }
    }

    if (creating || editing != null) {
        val current = editing
        WinDialog(
            lang = store.language,
            initial = current,
            onSave = { win ->
                if (!store.upsert(win)) {
                    toast(t("Nie udało się zapisać danych", "Could not save data", "No se pudieron guardar los datos"))
                }
                creating = false
                editing = null
            },
            onDelete = { id ->
                if (!store.delete(id)) {
                    toast(t("Nie udało się zapisać danych", "Could not save data", "No se pudieron guardar los datos"))
                }
                creating = false
                editing = null
            },
            onDismiss = {
                creating = false
                editing = null
            },
        )
    }

    importPreview?.let { list ->
        AlertDialog(
            onDismissRequest = { importPreview = null },
            title = { Text(t("Przywrócić kopię?", "Restore backup?", "¿Restaurar la copia?")) },
            text = {
                Text(
                    t(
                        "Kopia zawiera ${list.size} wygranych. Obecne dane zostaną zastąpione.",
                        "The backup contains ${list.size} wins. Current data will be replaced.",
                        "La copia contiene ${list.size} premios. Los datos actuales se reemplazarán.",
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (!store.replaceAll(list)) {
                        toast(t("Nie udało się zapisać danych", "Could not save data", "No se pudieron guardar los datos"))
                    }
                    importPreview = null
                }) { Text(t("Przywróć", "Restore", "Restaurar")) }
            },
            dismissButton = {
                TextButton(onClick = { importPreview = null }) { Text(t("Anuluj", "Cancel", "Cancelar")) }
            },
        )
    }
}
