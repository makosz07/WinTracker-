package com.macoshapps.wintracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import com.macoshapps.wintracker.data.WinStore
import com.macoshapps.wintracker.ui.WinColors
import com.macoshapps.wintracker.ui.WinTrackerApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Same preferences file as v0.1 so existing wins are kept.
        val store = WinStore(getSharedPreferences("wins", MODE_PRIVATE))
        setContent {
            MaterialTheme(colorScheme = WinColors) {
                WinTrackerApp(store)
            }
        }
    }
}
