package com.macoshapps.wintracker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.macoshapps.wintracker.data.WinStore
import com.macoshapps.wintracker.domain.Win
import com.macoshapps.wintracker.i18n.L
import java.util.Locale

@Composable
fun WinsScreen(store: WinStore, onAdd: () -> Unit, onEdit: (Win) -> Unit) {
    val t = L(store.language)
    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim().lowercase(Locale.ROOT)
    val list = store.wins.filter { w ->
        q.isEmpty() ||
            w.title.lowercase(Locale.ROOT).contains(q) ||
            w.tags.any { it.lowercase(Locale.ROOT).contains(q) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        PageHeader(t("Twoja lista", "Your list", "Tu lista"), t("Wygrane", "Wins", "Premios"))
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) {
            Text(t("+ Dodaj wygraną", "+ Add win", "+ Añadir premio"))
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            label = { Text(t("Szukaj po nazwie lub tagu", "Search by title or tag", "Buscar por nombre o etiqueta")) },
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))

        if (list.isEmpty()) {
            Muted(
                if (store.wins.isEmpty()) t("Nie masz jeszcze żadnych wygranych. Dodaj pierwszą.",
                    "No wins yet. Add your first one.", "Aún no tienes premios. Añade el primero.")
                else t("Brak wyników wyszukiwania.", "No matching wins.", "Sin resultados.")
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                items(list, key = { it.id }) { win ->
                    WinCard(win, store.language, onClick = { onEdit(win) })
                }
            }
        }
    }
}

@Composable
private fun WinCard(win: Win, lang: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    win.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    Fmt.money(win.amount, lang),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Spacer(Modifier.height(4.dp))
            Muted(Fmt.date(win.date, lang))
            if (win.tags.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    win.tags.take(4).forEach { Tag(it) }
                }
            }
        }
    }
}
