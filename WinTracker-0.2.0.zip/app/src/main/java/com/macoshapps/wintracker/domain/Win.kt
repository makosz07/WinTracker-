package com.macoshapps.wintracker.domain

import java.math.BigDecimal
import java.time.LocalDate

data class Win(
    val id: String,
    val title: String,
    val date: LocalDate,
    val amount: BigDecimal,
    val tags: List<String>,
) {
    companion object {
        const val MAX_TITLE = 100

        fun parseTags(raw: String): List<String> =
            raw.split(',').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    }
}
