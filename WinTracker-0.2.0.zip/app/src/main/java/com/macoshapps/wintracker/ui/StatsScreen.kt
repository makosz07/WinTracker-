package com.macoshapps.wintracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.macoshapps.wintracker.data.WinStore
import com.macoshapps.wintracker.domain.MonthRow
import com.macoshapps.wintracker.domain.Stats
import com.macoshapps.wintracker.i18n.L
import java.math.RoundingMode
import java.time.LocalDate

@Composable
fun StatsScreen(store: WinStore) {
    val t = L(store.language)
    val lang = store.language
    val stats = Stats.of(store.wins.toList(), LocalDate.now())

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { PageHeader(t("Analiza", "Analysis", "Análisis"), t("Statystyki", "Statistics", "Estadísticas")) }

        item {
            InfoCard {
                Row(Modifier.fillMaxWidth()) {
                    StatTile(t("Wygrane", "Wins", "Premios"), stats.count.toString(), Modifier.weight(1f))
                    StatTile(t("Łącznie", "Total", "Total"), Fmt.money(stats.total, lang), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    StatTile(t("Średnio", "Average", "Media"), Fmt.money(stats.average, lang), Modifier.weight(1f))
                    StatTile(
                        t("Największa", "Largest", "Mayor"),
                        stats.largest?.let { Fmt.money(it.amount, lang) } ?: "—",
                        Modifier.weight(1f),
                    )
                }
            }
        }

        item { SectionTitle(t("Ostatnie 12 miesięcy", "Last 12 months", "Últimos 12 meses")) }
        item { MonthBars(stats.lastMonths, lang) }

        item { SectionTitle(t("Lata", "Years", "Años")) }
        if (stats.byYear.isEmpty()) {
            item { Muted(t("Brak danych.", "No data yet.", "Sin datos.")) }
        }
        items(stats.byYear) { row ->
            SpacedRow(row.year.toString(), "${row.count} · ${Fmt.money(row.total, lang)}")
        }

        item { SectionTitle(t("Tagi", "Tags", "Etiquetas")) }
        if (stats.byTag.isEmpty()) {
            item { Muted(t("Brak tagów.", "No tags yet.", "Sin etiquetas.")) }
        }
        items(stats.byTag) { row ->
            SpacedRow(row.tag, "${row.count} · ${Fmt.money(row.total, lang)}")
        }

        item { SectionTitle(t("Największa wygrana", "Largest win", "Mayor premio")) }
        item {
            val largest = stats.largest
            if (largest == null) {
                Muted(t("Brak danych.", "No data yet.", "Sin datos."))
            } else {
                SpacedRow(largest.title, "${Fmt.money(largest.amount, lang)} · ${Fmt.date(largest.date, lang)}")
            }
        }
    }
}

@Composable
private fun MonthBars(rows: List<MonthRow>, lang: String) {
    val peak = rows.maxOfOrNull { it.total }?.takeIf { it.signum() > 0 }
    InfoCard {
        rows.forEach { row ->
            val fraction = if (peak == null) 0f else row.total.divide(peak, 4, RoundingMode.HALF_UP).toFloat()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    Fmt.month(row.month, lang),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.width(96.dp),
                )
                Box(
                    Modifier
                        .weight(1f)
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(fraction)
                            .height(10.dp)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
                Text(
                    "  ${row.count}",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.width(36.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
