package com.macoshapps.wintracker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.macoshapps.wintracker.BuildConfig
import com.macoshapps.wintracker.data.WinStore
import com.macoshapps.wintracker.i18n.L

@Composable
fun SettingsScreen(store: WinStore, onExport: () -> Unit, onImport: () -> Unit) {
    val t = L(store.language)
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        PageHeader(t("Personalizacja", "Preferences", "Preferencias"), t("Ustawienia", "Settings", "Ajustes"))

        SectionTitle(t("Język", "Language", "Idioma"))
        InfoCard {
            listOf("PL" to "Polski", "EN" to "English", "ES" to "Español").forEach { (code, label) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { store.setLanguage(code) }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = store.language == code, onClick = { store.setLanguage(code) })
                    Text(label, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }

        SectionTitle(t("Kopia zapasowa", "Backup", "Copia de seguridad"))
        InfoCard {
            Button(onClick = onExport, modifier = Modifier.fillMaxWidth()) {
                Text(t("Eksportuj JSON", "Export JSON", "Exportar JSON"))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
                Text(t("Importuj JSON", "Import JSON", "Importar JSON"))
            }
            Spacer(Modifier.height(8.dp))
            Muted(t(
                "Import najpierw pokazuje podgląd i zastępuje obecne dane po potwierdzeniu.",
                "Import shows a preview first and replaces current data after you confirm.",
                "La importación muestra una vista previa y reemplaza los datos tras confirmar.",
            ))
        }

        SectionTitle(t("O aplikacji", "About", "Acerca de"))
        InfoCard {
            Text("WinTracker", style = MaterialTheme.typography.titleMedium)
            Muted("Macosh Apps · ${t("wersja", "version", "versión")} ${BuildConfig.VERSION_NAME}")
        }
    }
}
