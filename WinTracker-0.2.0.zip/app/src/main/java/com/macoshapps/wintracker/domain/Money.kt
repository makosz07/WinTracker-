package com.macoshapps.wintracker.domain

import java.math.BigDecimal
import java.math.RoundingMode

object Money {
    val ZERO: BigDecimal = BigDecimal.ZERO.setScale(2)

    /** Accepts "1 234,50", "1234.5" or blank (zero). Returns null for anything that is not a non-negative amount. */
    fun parse(input: String): BigDecimal? {
        val normalized = input.replace(Regex("\\s"), "").replace(',', '.')
        if (normalized.isEmpty()) return ZERO
        return try {
            val value = BigDecimal(normalized)
            if (value.signum() < 0) null else value.setScale(2, RoundingMode.HALF_UP)
        } catch (e: NumberFormatException) {
            null
        }
    }
}
