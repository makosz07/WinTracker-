package com.macoshapps.wintracker.ui

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

val WinColors = darkColorScheme(
    primary = Color(0xFFF5C453),
    onPrimary = Color(0xFF2A1F00),
    primaryContainer = Color(0xFF3F3210),
    onPrimaryContainer = Color(0xFFFFE9A8),
    secondary = Color(0xFF8FB8FF),
    background = Color(0xFF0E131B),
    onBackground = Color(0xFFEEF2F7),
    surface = Color(0xFF172030),
    onSurface = Color(0xFFEEF2F7),
    surfaceVariant = Color(0xFF223047),
    onSurfaceVariant = Color(0xFF9AA8BE),
    error = Color(0xFFFF8A8A),
)
