package com.macoshapps.wintracker.data

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.macoshapps.wintracker.domain.Money
import com.macoshapps.wintracker.domain.Win
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.time.LocalDate
import java.util.UUID

/**
 * Holds the wins list and persists it on every change. Data is written synchronously with commit(),
 * so a reported success means the data is on disk.
 */
class WinStore(private val prefs: SharedPreferences) {
    val wins = mutableStateListOf<Win>()

    var language by mutableStateOf(prefs.getString(KEY_LANG, "PL") ?: "PL")
        private set

    init {
        val stored = prefs.getString(KEY_WINS, null) ?: "[]"
        try {
            wins.addAll(decode(stored))
        } catch (e: JSONException) {
            // Keep the unreadable copy under its own key; the next save must not destroy it.
            prefs.edit().putString(KEY_WINS_UNREADABLE, stored).commit()
        }
    }

    fun setLanguage(code: String) {
        language = code
        prefs.edit().putString(KEY_LANG, code).apply()
    }

    /** Adds a new win (at the top) or replaces the one with the same id. Returns false if the save failed. */
    fun upsert(win: Win): Boolean {
        val index = wins.indexOfFirst { it.id == win.id }
        if (index >= 0) wins[index] = win else wins.add(0, win)
        return persist()
    }

    fun delete(id: String): Boolean {
        wins.removeAll { it.id == id }
        return persist()
    }

    fun replaceAll(list: List<Win>): Boolean {
        wins.clear()
        wins.addAll(list)
        return persist()
    }

    fun exportJson(): String = encode(wins.toList())

    private fun persist(): Boolean =
        prefs.edit().putString(KEY_WINS, encode(wins.toList())).commit()

    companion object {
        const val KEY_WINS = "wins"
        const val KEY_WINS_UNREADABLE = "wins_unreadable"
        const val KEY_LANG = "lang"
        const val SCHEMA = 2

        fun encode(wins: List<Win>): String {
            val array = JSONArray()
            wins.forEach { w ->
                array.put(
                    JSONObject()
                        .put("id", w.id)
                        .put("title", w.title)
                        .put("date", w.date.toString())
                        .put("amount", w.amount.toPlainString())
                        .put("tags", JSONArray(w.tags))
                )
            }
            return JSONObject().put("schema", SCHEMA).put("wins", array).toString()
        }

        /** Reads the v0.1 array format and the v0.2 object format. Throws JSONException on invalid JSON. */
        fun decode(json: String): List<Win> {
            val text = json.trim()
            val array = if (text.startsWith("[")) {
                JSONArray(text)
            } else {
                JSONObject(text).optJSONArray("wins") ?: throw JSONException("Missing wins array")
            }
            val out = ArrayList<Win>(array.length())
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val title = o.optString("title").trim()
                if (title.isEmpty()) continue
                val date = runCatching { LocalDate.parse(o.optString("date")) }.getOrDefault(LocalDate.now())
                val amountText = o.optString("amount").ifEmpty { o.optString("value") }
                val amount = Money.parse(amountText) ?: Money.ZERO
                val id = o.optString("id").ifEmpty { UUID.randomUUID().toString() }
                out.add(Win(id, title.take(Win.MAX_TITLE), date, amount, readTags(o.opt("tags"))))
            }
            return out
        }

        private fun readTags(raw: Any?): List<String> {
            val parts: List<String> = when (raw) {
                is JSONArray -> (0 until raw.length()).map { raw.optString(it) }
                is String -> raw.split(',')
                else -> emptyList()
            }
            return parts.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        }
    }
}
