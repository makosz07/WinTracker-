package com.macoshapps.wintracker.i18n

/** Picks the Polish, English or Spanish text for the current language code ("PL", "EN", "ES"). */
class L(private val lang: String) {
    operator fun invoke(pl: String, en: String, es: String): String = when (lang) {
        "EN" -> en
        "ES" -> es
        else -> pl
    }
}
