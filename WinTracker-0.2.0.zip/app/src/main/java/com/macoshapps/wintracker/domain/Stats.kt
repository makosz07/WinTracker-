package com.macoshapps.wintracker.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.YearMonth

data class YearRow(val year: Int, val count: Int, val total: BigDecimal)
data class TagRow(val tag: String, val count: Int, val total: BigDecimal)
data class MonthRow(val month: YearMonth, val count: Int, val total: BigDecimal)

data class Stats(
    val count: Int,
    val total: BigDecimal,
    val average: BigDecimal,
    val largest: Win?,
    val byYear: List<YearRow>,
    val byTag: List<TagRow>,
    val lastMonths: List<MonthRow>,
) {
    companion object {
        fun of(wins: List<Win>, today: LocalDate, months: Int = 12): Stats {
            val total = sum(wins)
            val average = if (wins.isEmpty()) {
                BigDecimal.ZERO.setScale(2)
            } else {
                total.divide(BigDecimal(wins.size), 2, RoundingMode.HALF_UP)
            }
            val byYear = wins.groupBy { it.date.year }
                .map { (year, list) -> YearRow(year, list.size, sum(list)) }
                .sortedByDescending { it.year }
            val byTag = wins.flatMap { w -> w.tags.map { tag -> tag to w } }
                .groupBy({ it.first }, { it.second })
                .map { (tag, list) -> TagRow(tag, list.size, sum(list)) }
                .sortedWith(compareByDescending<TagRow> { it.count }.thenBy { it.tag.lowercase() })
            val thisMonth = YearMonth.from(today)
            val lastMonths = (months - 1 downTo 0).map { back ->
                val month = thisMonth.minusMonths(back.toLong())
                val inMonth = wins.filter { YearMonth.from(it.date) == month }
                MonthRow(month, inMonth.size, sum(inMonth))
            }
            return Stats(
                count = wins.size,
                total = total,
                average = average,
                largest = wins.maxByOrNull { it.amount },
                byYear = byYear,
                byTag = byTag,
                lastMonths = lastMonths,
            )
        }

        private fun sum(list: List<Win>): BigDecimal =
            list.fold(BigDecimal.ZERO) { acc, w -> acc + w.amount }
    }
}
