package com.macoshapps.wintracker.ui

import java.math.BigDecimal
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

object Fmt {
    fun locale(lang: String): Locale = Locale.forLanguageTag(
        when (lang) {
            "EN" -> "en-GB"
            "ES" -> "es-ES"
            else -> "pl-PL"
        }
    )

    fun money(value: BigDecimal, lang: String): String {
        val format = NumberFormat.getNumberInstance(locale(lang))
        format.minimumFractionDigits = 2
        format.maximumFractionDigits = 2
        return format.format(value)
    }

    fun date(date: LocalDate, lang: String): String =
        date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(locale(lang)))

    fun month(month: YearMonth, lang: String): String =
        month.format(DateTimeFormatter.ofPattern("LLL yyyy", locale(lang)))
}
