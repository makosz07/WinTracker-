package com.macoshapps.wintracker.domain

import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoneyTest {
    @Test
    fun parsesCommaDecimalsAndSpaces() {
        assertEquals(BigDecimal("1234.50"), Money.parse("1 234,50"))
        assertEquals(BigDecimal("1234.50"), Money.parse("1234.5"))
    }

    @Test
    fun blankIsZero() {
        assertEquals(BigDecimal("0.00"), Money.parse("   "))
    }

    @Test
    fun rejectsInvalidAndNegative() {
        assertNull(Money.parse("abc"))
        assertNull(Money.parse("-1"))
    }
}
