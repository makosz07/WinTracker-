package com.macoshapps.wintracker.domain

import java.math.BigDecimal
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class StatsTest {
    private val wins = listOf(
        Win("1", "A", LocalDate.of(2025, 3, 1), BigDecimal("100.00"), listOf("x", "y")),
        Win("2", "B", LocalDate.of(2026, 9, 15), BigDecimal("50.50"), listOf("x")),
    )
    private val today = LocalDate.of(2026, 10, 18)

    @Test
    fun totalsAndAverage() {
        val s = Stats.of(wins, today)
        assertEquals(2, s.count)
        assertEquals(0, BigDecimal("150.50").compareTo(s.total))
        assertEquals(0, BigDecimal("75.25").compareTo(s.average))
        assertEquals("A", s.largest?.title)
    }

    @Test
    fun yearsNewestFirst() {
        assertEquals(listOf(2026, 2025), Stats.of(wins, today).byYear.map { it.year })
    }

    @Test
    fun tagsSortedByCount() {
        val first = Stats.of(wins, today).byTag.first()
        assertEquals("x", first.tag)
        assertEquals(2, first.count)
    }

    @Test
    fun lastTwelveMonthsEndingThisMonth() {
        val months = Stats.of(wins, today).lastMonths
        assertEquals(12, months.size)
        assertEquals(java.time.YearMonth.of(2025, 11), months.first().month)
        assertEquals(java.time.YearMonth.of(2026, 10), months.last().month)
        assertEquals(0, BigDecimal.ZERO.compareTo(months.last().total))
    }

    @Test
    fun emptyListHasZeroAverage() {
        val s = Stats.of(emptyList(), today)
        assertEquals(0, s.count)
        assertEquals(0, BigDecimal.ZERO.compareTo(s.average))
        assertEquals(null, s.largest)
    }
}
